mvn install
java -jar target/off-latice-ca-1.0-SNAPSHOT-jar-with-dependencies.jar
python3.10 plots/plot.py
