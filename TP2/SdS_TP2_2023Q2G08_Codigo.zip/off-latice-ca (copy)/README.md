# Off latice Celular Automata

...

## Prerequisites

- Java JDK 11: Make sure you have Java Development Kit 11 or higher installed.
- Maven Compiler Plugin: A Maven plugin to compile Java sources.

